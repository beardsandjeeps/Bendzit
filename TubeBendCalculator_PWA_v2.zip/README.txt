Tube Bend Calculator — Multi-bend PWA (v2)

• Add unlimited bends. Each bend has Angle, CLR, and a Straight-after value.
• Enter start/end tails.
• Enter tube OD + wall thickness and material (steel/aluminum) for a weight estimate.
• Units toggle (in/mm). Works offline and is installable via Add to Home Screen.
• Bend mark column shows the end-of-bend mark from the cut end.
